========================================================================
  MT5 Trading Journal — Local Sync Connector
========================================================================

Requirements:
1. Windows PC with MetaTrader 5 installed & running
2. Python 3.11 or higher (from https://www.python.org/downloads/)
   * IMPORTANT: When installing Python, check the box:
     [x] "Add Python to PATH"

Quick Start:
1. Extract all files from this ZIP into any folder (e.g. C:\TJ-Connector).
2. Double-click `run_connector.bat` (or open a terminal and run `python local_sync_agent.py`).
3. Follow the one-time interactive prompt:
   - Backend URL: Press Enter for default (or paste your Render backend URL)
   - Sync Token: Paste your sync token from your Trading Journal Settings or Onboarding.
4. Leave the terminal running in the background while MetaTrader 5 is open.
   Your positions and trades will automatically stream live to your journal!

Troubleshooting:
- If `run_connector.bat` closes immediately, open Command Prompt in this folder and run:
    pip install MetaTrader5 httpx websockets python-dotenv
    python local_sync_agent.py
- Make sure "Allow Algo Trading" and automated API access is enabled in MetaTrader 5:
    Tools -> Options -> Expert Advisors -> Allow algorithmic trading.
