========================================================================
  MT5 Trading Journal — Local Sync Connector
========================================================================

Requirements:
1. Windows PC with MetaTrader 5 installed & running
2. Python 3.11 or higher (from https://www.python.org/downloads/)
   * IMPORTANT: When installing Python, check the box:
     [x] "Add Python to PATH"

Quick Start:
1. Extract all files from this ZIP into any folder (e.g. C:\TJ-Connector).
2. Double-click `run_connector.bat` (or right-click `run_connector.ps1` -> Run with PowerShell).
3. The connector will automatically detect your MetaTrader 5 installation and bring up the terminal GUI.
4. If prompted on first run:
   - Backend URL: Press Enter for default
   - Sync Token: Paste your sync token from your Trading Journal Settings or Onboarding.
5. Leave the connector running in the background while trading!
   Your positions and trades will automatically stream live to your journal.

Troubleshooting:
- If `run_connector.bat` closes immediately, open Command Prompt in this folder and run:
    pip install MetaTrader5 httpx websockets python-dotenv
    python local_sync_agent.py
- Make sure "Allow Algo Trading" is enabled in MetaTrader 5:
    Tools -> Options -> Expert Advisors -> Allow algorithmic trading.
